class Item {
  String title;
  double price;
  Item({this.title, this.price});
}