import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import 'package:firebase_database/firebase_database.dart';


class ProduitService {
  FirebaseDatabase database = FirebaseDatabase.instance;
  Firestore _firestore = Firestore.instance;
  String ref = 'produits';

  void addProd(String name) {
    var id = Uuid();
    String idProduit = id.v1();

    _firestore.collection(ref).document(idProduit).setData({'produit': name});
  }
    addProduit(Map value){
    database.reference().child(ref).push().set(
        value
    ).catchError((e) => { print(e.toString())});
  }

  Future<List<DocumentSnapshot>> getProduits() =>
      _firestore.collection(ref).getDocuments().then((snaps) {
        return snaps.documents;
      });


  Future<List<DocumentSnapshot>> getSuggestions(String suggestion) =>
      _firestore.collection(ref).where('produit', isEqualTo: suggestion).getDocuments().then((snap){
        return snap.documents;
      });

}